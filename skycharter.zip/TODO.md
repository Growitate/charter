# Sky Charter demo outcomes

- [x] **Premium responsive public website:** Build Home, Services, How It Works, Trust, About, FAQ, and Legal pages with a high-trust, concierge-led visual language. The site must clearly explain that it is an enquiry-led marketplace, not a self-service booking engine.
- [x] **Persistent contact affordance:** Keep WhatsApp and callback actions available throughout the public experience as front-end-only demo actions without real integrations.
- [x] **Verified vendor directory:** Show approximately 20 mock verified charter partners with searchable cards and filters for aircraft type, budget, and region.
- [x] **Vendor detail conversion surface:** Show verified badge, licences, insurance and safety highlights, fleet, amenities, indicative all-inclusive price point, onboarding strip, and a prominent “Request this charter” CTA.
- [x] **Streamlined request flow:** Provide a multi-step “Request a Charter” flow covering trip details, preferences, add-ons, and contact information.
- [x] **Request confirmation:** After the form flow, show a mock reference ID and the message that a concierge will make contact within 30 minutes.
- [x] **Front-end-only enquiry inbox:** Show mock enquiries, a status pipeline, assignee, notes/reminders, filters, and an export affordance in a simple back-office view.
- [x] **Static/demo constraints:** Use mock/static data only; do not add backend, payments, authentication, or real integrations.
