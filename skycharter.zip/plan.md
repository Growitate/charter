# Sky Charter — implementation and design plan

## Product direction
A frontend-only Vite demo for an enquiry-led private aviation concierge marketplace. The experience should feel like a trusted private office: curated partners, indicative pricing, clear verification, and a human concierge who closes each booking offline.

## Design movement
**Airy aviation editorial** — the visual language of Tripvora’s reference: an open white canvas, oversized lightweight sans-serif type, rounded image-led sections, glassy overlays, and muted blue-green accents.

## Core principles
- **Air and space:** make room for the image, the message, and the next step.
- **Soft confidence:** use rounded surfaces, quiet borders, and light hierarchy instead of heavy decoration.
- **Human planning:** keep the concierge story present without making the interface feel like an operations tool.
- **Clear next actions:** every primary CTA moves the visitor toward a flight request or conversation.

## Color philosophy
White and soft mist surfaces create the calm, open feeling of a premium travel journal. Deep charcoal anchors typography and actions, while muted blue-green carries the aviation and hospitality cues without becoming a conventional airline blue.

## Layout paradigm
A wide rounded hero card anchors each primary page. Sections breathe below it with left-aligned editorial copy, generous vertical spacing, rounded cards, and occasional full-width image bands. Operational inbox screens retain their scan-friendly grids.

## Signature elements
1. Minimal arrow-like Sky Charter mark with compact letter-spaced wordmark.
2. Large rounded aviation imagery with dark translucent information cards.
3. Tiny uppercase eyebrow labels and soft blue-green section surfaces.

## Interaction philosophy
Interactions should reassure. Filters update immediately, CTAs open the next human-led step, and every meaningful form section explains what happens next. Demo-only actions use gentle toast feedback instead of pretending to submit real payments or messages.

## Animation
Use subtle 180–260ms ease-out transitions for cards, filters, nav, and step progression. Hero content fades upward on load. Avoid parallax and looping motion that makes a luxury experience feel noisy.

## Typography system
Use `DM Sans` for interface, navigation, and numeric details. Use `Cormorant Garamond` for display headlines and pull quotes. Keep headlines large and airy; use 11px upper-case labels with letter spacing for operational metadata.

## Brand essence
A private aviation concierge for travellers who value certainty as much as speed. **Poised, discreet, exacting.**

## Brand voice
Headlines are confident and direct: “Your time deserves a better route.” CTAs are calm invitations: “Request this charter” and “Speak with a concierge.”

## Wordmark & logo
A compact champagne monogram “SC” inside a thin rounded square, paired with a letter-spaced Sky Charter wordmark. The monogram echoes a boarding pass stamp without feeling like an airline logo.

## Signature brand color
Champagne `#D3B27A` on midnight `#0B1626`.

## Implementation structure
- `src/App.jsx`: route-aware app shell, reusable UI components, mock data, and demo interactions.
- `src/styles.css`: design tokens, responsive layout, transitions, and page-specific styling.
- `public/manus-routes.json`: complete route manifest for the demo.
- `app.config.ts`: project logo metadata.
