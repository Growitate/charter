# Sky Charter — Private Aviation Concierge Demo

Frontend-only Vite/React demo based on the supplied charter broker blueprint. It uses static mock data and responsive page components for the public marketplace, enquiry flow, and operations inbox.

## Run locally

```bash
npm install
npm run dev
```

The app is intentionally front-end only: there are no real payments, authentication, WhatsApp messages, or enquiry persistence. The visible actions use demo feedback states.
